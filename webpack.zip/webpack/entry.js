require('./style.css') // 载入 style.css
document.write('It works123.');
document.write(require('./module.js')); // 添加模块